import { Data } from "../interfaces";

export const data: Data[] = [
    {id: 1,content: 'آمد',status: 'آ'},{id: 2,content: 'آمد',status: 'آ'},
   
    {id: 6,content: 'بد',status: 'ب'},{id: 7,content: 'Flash',status: 'ب'},

    {id: 11,content: 'Green Lantern',status: 'س'},{id: 12,content: 'Green Lantern',status: 'س'},

    {id: 16,content: 'Batman',status: 'د'},{id: 17,content: 'Batman',status: 'د'},

    {id: 21,content: 'Batman',status: 'ت'},{id: 22,content: 'Batman',status: 'ت'},
]
